# -*- coding: utf-8 -*-
### required - do no delete
def user(): return dict(form=auth())
def download(): return response.download(request,db)
def call(): return service()
### end requires

def error():
    return dict()


def index():
    grid=SQLFORM.grid(db.TipoUnidade, user_signature=False)
    return locals()
    

def teste():
    grid=SQLFORM.grid(db.Produto, user_signature=False)
    return locals()


def error():
    return dict()